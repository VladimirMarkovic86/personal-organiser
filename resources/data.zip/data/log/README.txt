Neo4j Logs
=======================================

Server logs, including:

* neo4j.log - graph database logging
* wrapper.log - logging for the service wrapper
 



